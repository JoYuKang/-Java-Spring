package info.thecodinglive.photoapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PhotoApp {
    public static void main(String ar[]) {
        SpringApplication.run(PhotoApp.class, ar);
    }
}
